package com.example.mylittlelibrary

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class BookDb(context: Context) : SQLiteOpenHelper(context, "little_library.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE books (id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, author TEXT, isbn TEXT, status TEXT NOT NULL, finished_date TEXT)"
        )
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}

    fun add(title: String, author: String, isbn: String, status: String, date: String) {
        val values = ContentValues().apply {
            put("title", title); put("author", author); put("isbn", isbn)
            put("status", status); put("finished_date", date)
        }
        writableDatabase.insert("books", null, values)
    }

    fun updateStatus(id: Long, status: String, date: String) {
        val values = ContentValues().apply { put("status", status); put("finished_date", date) }
        writableDatabase.update("books", values, "id=?", arrayOf(id.toString()))
    }

    fun delete(id: Long) { writableDatabase.delete("books", "id=?", arrayOf(id.toString())) }

    fun all(): List<Book> {
        val result = mutableListOf<Book>()
        readableDatabase.rawQuery("SELECT id,title,author,isbn,status,finished_date FROM books ORDER BY id DESC", null).use { c ->
            while (c.moveToNext()) {
                result.add(Book(c.getLong(0), c.getString(1), c.getString(2) ?: "",
                    c.getString(3) ?: "", c.getString(4), c.getString(5) ?: ""))
            }
        }
        return result
    }
}
