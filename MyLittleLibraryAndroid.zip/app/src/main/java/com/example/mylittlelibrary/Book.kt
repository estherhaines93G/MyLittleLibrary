package com.example.mylittlelibrary

data class Book(
    val id: Long,
    val title: String,
    val author: String,
    val isbn: String,
    val status: String,
    val finishedDate: String
)
