package com.example.mylittlelibrary

import android.Manifest
import android.app.Activity
import android.app.DatePickerDialog
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.common.InputImage
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private lateinit var db: BookDb
    private lateinit var root: LinearLayout
    private lateinit var listArea: LinearLayout
    private lateinit var scannerPreview: PreviewView
    private val cameraExecutor = Executors.newSingleThreadExecutor()
    private var scanLocked = false
    private var selectedDate = today()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = BookDb(this)
        showHome()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun today() = SimpleDateFormat("yyyy-MM-dd", Locale.UK).format(Calendar.getInstance().time)

    private fun text(value: String, size: Float = 16f, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = value; textSize = size
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
            setTextColor(0xFF26372D.toInt())
            setPadding(dp(4), dp(6), dp(4), dp(6))
        }

    private fun button(label: String, action: () -> Unit) = Button(this).apply {
        text = label; setOnClickListener { action() }
    }

    private fun field(hintText: String) = EditText(this).apply {
        hint = hintText; textSize = 16f; singleLine = true
        setPadding(dp(12), dp(10), dp(12), dp(10))
    }

    private fun shell(title: String) {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFFF7F4EC.toInt())
            setPadding(dp(16), dp(12), dp(16), dp(8))
        }
        val header = TextView(this).apply {
            text = "📚  MY LITTLE LIBRARY\n$title"
            textSize = 23f; setTextColor(0xFF34483B.toInt())
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(0, dp(8), 0, dp(14))
        }
        root.addView(header)
        setContentView(root)
    }

    private fun showHome() {
        shell("Your reading journey")
        val books = db.all()
        val finished = books.count { it.status == "Read" }
        root.addView(text("${books.size} books  •  $finished finished", 15f, true))
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        actions.addView(button("📷 Scan ISBN") { requestCameraAndScan() }, LinearLayout.LayoutParams(0, dp(52), 1f))
        actions.addView(button("＋ Add manually") { showAddForm("", "", "") }, LinearLayout.LayoutParams(0, dp(52), 1f))
        root.addView(actions)
        root.addView(text("MY BOOKSHELF", 18f, true))
        val scroll = ScrollView(this)
        listArea = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(listArea)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        refreshBooks()
    }

    private fun refreshBooks() {
        if (!::listArea.isInitialized) return
        listArea.removeAllViews()
        val books = db.all()
        if (books.isEmpty()) listArea.addView(text("Your bookshelf is empty. Scan a barcode or add a book to get started."))
        books.forEach { book ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setBackgroundColor(0xFFFFFFFF.toInt())
                setPadding(dp(12), dp(8), dp(12), dp(8))
            }
            card.addView(text(book.title, 18f, true))
            card.addView(text(if (book.author.isBlank()) "Author unknown" else book.author, 14f))
            card.addView(text("${book.status}${if (book.status == "Read" && book.finishedDate.isNotBlank()) " • Finished ${book.finishedDate}" else ""}", 13f))
            val controls = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            controls.addView(button("Mark reading") { db.updateStatus(book.id, "Currently reading", ""); refreshBooks() })
            controls.addView(button("Mark read") { chooseDate { date -> db.updateStatus(book.id, "Read", date); refreshBooks() } })
            controls.addView(button("Delete") { db.delete(book.id); refreshBooks() })
            card.addView(controls)
            val lp = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) }
            listArea.addView(card, lp)
        }
    }

    private fun showAddForm(titleValue: String, authorValue: String, isbnValue: String) {
        shell("Add a book")
        val title = field("Book title"); title.setText(titleValue)
        val author = field("Author"); author.setText(authorValue)
        val isbn = field("ISBN"); isbn.setText(isbnValue)
        val statuses = arrayOf("Want to read", "Currently reading", "Read")
        val spinner = Spinner(this)
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, statuses)
        root.addView(text("Title *")); root.addView(title)
        root.addView(text("Author")); root.addView(author)
        root.addView(text("ISBN")); root.addView(isbn)
        root.addView(text("Reading status")); root.addView(spinner)
        root.addView(button("Choose finished date") { chooseDate { selectedDate = it; Toast.makeText(this, "Finished: $it", Toast.LENGTH_SHORT).show() } })
        root.addView(button("Save to my library") {
            if (title.text.toString().isBlank()) {
                title.error = "Please enter a book title"; return@button
            }
            val status = spinner.selectedItem.toString()
            db.add(title.text.toString().trim(), author.text.toString().trim(), isbn.text.toString().trim(),
                status, if (status == "Read") selectedDate else "")
            showHome()
        })
        root.addView(button("Cancel") { showHome() })
    }

    private fun chooseDate(onChosen: (String) -> Unit) {
        val cal = Calendar.getInstance()
        DatePickerDialog(this, { _, year, month, day ->
            val date = String.format(Locale.UK, "%04d-%02d-%02d", year, month + 1, day)
            onChosen(date)
        }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()
    }

    private fun requestCameraAndScan() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            showScanner()
        } else ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.CAMERA), 41)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 41 && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) showScanner()
        else Toast.makeText(this, "Camera permission is needed to scan book barcodes.", Toast.LENGTH_LONG).show()
    }

    private fun showScanner() {
        shell("Scan a book barcode")
        root.addView(text("Hold the ISBN barcode steady inside the camera view.", 14f))
        scannerPreview = PreviewView(this)
        root.addView(scannerPreview, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(button("Cancel scan") { showHome() })
        startCamera()
    }

    private fun startCamera() {
        val providerFuture = ProcessCameraProvider.getInstance(this)
        providerFuture.addListener({
            val provider = providerFuture.get()
            val preview = Preview.Builder().build().also { it.setSurfaceProvider(scannerPreview.surfaceProvider) }
            val analysis = ImageAnalysis.Builder().setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).build()
            val scanner = BarcodeScanning.getClient()
            analysis.setAnalyzer(cameraExecutor) { proxy ->
                if (scanLocked) { proxy.close(); return@setAnalyzer }
                val media = proxy.image
                if (media == null) { proxy.close(); return@setAnalyzer }
                val image = InputImage.fromMediaImage(media, proxy.imageInfo.rotationDegrees)
                scanner.process(image)
                    .addOnSuccessListener { codes ->
                        val code = codes.firstOrNull { it.rawValue?.matches(Regex("^(978|979)[0-9]{10}$")) == true }
                        if (code != null && !scanLocked) {
                            scanLocked = true
                            val isbn = code.rawValue!!
                            runOnUiThread {
                                provider.unbindAll()
                                lookupBook(isbn)
                            }
                        }
                    }
                    .addOnCompleteListener { proxy.close() }
            }
            try {
                provider.unbindAll()
                provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, preview, analysis)
            } catch (e: Exception) {
                Toast.makeText(this, "Unable to start camera: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun lookupBook(isbn: String) {
        shell("Looking up your book")
        root.addView(text("ISBN detected: $isbn"))
        root.addView(text("Searching Google Books…"))
        Thread {
            try {
                val query = URLEncoder.encode("isbn:$isbn", "UTF-8")
                val connection = (URL("https://www.googleapis.com/books/v1/volumes?q=$query&maxResults=1").openConnection() as HttpURLConnection)
                connection.connectTimeout = 10000
                connection.readTimeout = 10000
                val body = connection.inputStream.bufferedReader().use { it.readText() }
                connection.disconnect()
                val items = JSONObject(body).optJSONArray("items")
                val info = if (items != null && items.length() > 0) items.getJSONObject(0).getJSONObject("volumeInfo") else null
                val title = info?.optString("title", "") ?: ""
                val authors = info?.optJSONArray("authors")
                val author = if (authors != null && authors.length() > 0) authors.getString(0) else ""
                runOnUiThread {
                    if (title.isBlank()) showAddForm("", "", isbn)
                    else showAddForm(title, author, isbn)
                }
            } catch (e: Exception) {
                runOnUiThread {
                    Toast.makeText(this, "Lookup failed. You can enter the details manually.", Toast.LENGTH_LONG).show()
                    showAddForm("", "", isbn)
                }
            }
        }.start()
    }

    override fun onDestroy() {
        super.onDestroy()
        cameraExecutor.shutdown()
    }
}
